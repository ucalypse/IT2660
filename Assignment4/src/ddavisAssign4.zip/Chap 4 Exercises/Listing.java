/*
Donald Davis
IT 2660 Data Structures & Algorithms CRN 13907
Due March 9, Spring 2017
Chapter 4 Exercise 27
 */
public class Listing {
    String name;
    int id;
    double gpa;

    public Listing(String n, int i, double g)   {
        name = n;
        id=i;
        gpa = g;
    }
}
