/*
Donald Davis
IT 2660 Data Structures & Algorithms CRN 13907
Due March 30, Spring 2017
Chapter 5 Exercise 40
 */
public class Ticket {
    public String name;
    public int seatNumber;

    public Ticket(String ticketName, int number)  {
     name = ticketName;
     seatNumber = number;
    }
}
